let text = document.getElementById('text');
let leaf = document.getElementById('leaf');
let hill1 = document.getElementById('hill1');
let hill4 = document.getElementById('hill4');
let hill5 = document.getElementById('hill5');

// 1. Move the mountains when scrolling
window.addEventListener('scroll', () => {
    let value = window.scrollY;
    
    if(text) text.style.marginTop = value * 2.5 + 'px';
    if(leaf) {
        leaf.style.top = value * -1.5 + 'px';
        leaf.style.left = value * 1.5 + 'px';
    }
    if(hill5) hill5.style.left = value * 1.5 + 'px';
    if(hill4) hill4.style.left = value * -1.5 + 'px';
    if(hill1) hill1.style.top = value * 1 + 'px';
});

// 2. Make the arrow scroll smoothly to the craft gallery
const scrollArrow = document.getElementById('scroll-arrow');
if (scrollArrow) {
    scrollArrow.addEventListener('click', () => {
        const targetSection = document.getElementById('craft-gallery-area');
        if (targetSection) {
            targetSection.scrollIntoView();
        }
    });
}
const backToTopBtn = document.getElementById('back-to-top');

window.addEventListener('scroll', () => {
    // Show button after scrolling down 400px
    if (window.scrollY > 400) {
        backToTopBtn.classList.add('show');
    } else {
        backToTopBtn.classList.remove('show');
    }
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({
        top: 0,
        behavior: 'smooth'
    });
});
const navLinks = document.querySelectorAll('.navigation a');

navLinks.forEach(link => {
    link.addEventListener('click', function() {
        // Remove 'active' class from all links
        navLinks.forEach(nav => nav.classList.remove('active'));
        // Add 'active' class to the one we just clicked
        this.classList.add('active');
    });
});


// --- OPEN/CLOSE CONTACT POPUP ---
function openContact() {
    document.getElementById('contact-modal').style.display = 'flex';
}

function closeContact() {
    document.getElementById('contact-modal').style.display = 'none';
}