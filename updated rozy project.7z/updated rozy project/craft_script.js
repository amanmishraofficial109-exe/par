// ==========================================
// CRAFT & CREATE YOUTUBE API LOGIC
// ==========================================

// 👇 PUT YOUR WORKING API KEY HERE 👇
const API_KEY = 'AIzaSyBAod95K6vBdKOzCZaBOwPjpjhQ3vVSxQo';
let currentQuery = 'best art and craft tutorials';
let nextPageToken = '';
let isFetching = false;

// DOM Elements
const galleryContainer = document.getElementById('video-gallery');
const watchSection = document.getElementById('watch-section');
const sideGallery = document.getElementById('side-gallery');
const youtubePlayer = document.getElementById('youtube-player');
const nowPlayingTitle = document.getElementById('now-playing-title');
const searchInput = document.getElementById('search-input');
const searchBtn = document.getElementById('search-btn');

// 1. Fetch Videos from YouTube
async function fetchCraftVideos(isNewSearch = false) {
    if (isFetching) return;
    isFetching = true;
    
    if (isNewSearch) { 
        galleryContainer.innerHTML = ''; 
        nextPageToken = ''; 
    }

    // UPDATED API URL:
    // - videoDuration=medium: Blocks Shorts (only 4-20 min videos)
    // - videoCategoryId=26: Targets "How-to & Style"
    const apiUrl = `https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=12&q=${encodeURIComponent(currentQuery)}&type=video&videoEmbeddable=true&videoDuration=medium&videoCategoryId=26&pageToken=${nextPageToken}&key=${API_KEY}`;

    try {
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data.error) {
            galleryContainer.innerHTML += `<h3 style="grid-column: 1/-1; text-align: center; color: red; padding: 40px;">API Error: ${data.error.message}</h3>`;
            isFetching = false;
            return;
        }

        nextPageToken = data.nextPageToken || '';
        
        if (data.items && data.items.length > 0) {
            data.items.forEach(item => {
                if(item.id.videoId) {
                    createCard(item.id.videoId, item.snippet.thumbnails.high.url, item.snippet.title);
                }
            });
        } else if (isNewSearch) {
            galleryContainer.innerHTML = `<h3 style="grid-column: 1/-1; text-align: center; padding: 40px; color: #2c3e50;">No videos found. Try another search!</h3>`;
        }
        
        isFetching = false;
    } catch (error) {
        console.error("Fetch Error: ", error);
        isFetching = false;
    }
}

// 2. Create Video Cards
function createCard(videoId, img, title) {
    const card = document.createElement('div');
    card.className = 'video-card';
    card.setAttribute('data-id', videoId);
    card.innerHTML = `<img src="${img}" alt="thumbnail" class="thumbnail"><div class="video-info"><h3 class="video-title">${title}</h3></div>`;
    
    card.addEventListener('click', () => openVideo(videoId, title));
    galleryContainer.appendChild(card);
}

// 3. Open Video in Theater Mode
function openVideo(videoId, title) {
    youtubePlayer.src = `https://www.youtube.com/embed/${videoId}?autoplay=1`;
    nowPlayingTitle.innerText = title;
    
    watchSection.classList.remove('hidden');
    
    // Copy current gallery to side feed
    sideGallery.innerHTML = galleryContainer.innerHTML;
    sideGallery.querySelectorAll('.video-card').forEach((card) => {
        card.addEventListener('click', () => {
            openVideo(card.getAttribute('data-id'), card.querySelector('.video-title').innerText);
        });
    });
    
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// 4. Close Theater Mode
document.getElementById('close-watch').addEventListener('click', () => {
    youtubePlayer.src = ""; 
    watchSection.classList.add('hidden');
});

// 5. Search Logic (Forces Arts & Craft context)
searchBtn.addEventListener('click', () => {
    const userInput = searchInput.value.trim();
    if (userInput !== "") {
        // Hard-coding "art and craft" into the query so generic searches don't break the theme
        currentQuery = `${userInput} art and craft DIY tutorial`;
        fetchCraftVideos(true);
    }
});

searchInput.addEventListener('keypress', (e) => { 
    if (e.key === 'Enter') searchBtn.click(); 
});

// 6. Infinite Scroll Sensor
window.addEventListener('scroll', () => {
    if (watchSection && watchSection.classList.contains('hidden')) {
        const { scrollTop, scrollHeight, clientHeight } = document.documentElement;
        
        // Trigger fetch when 600px from the bottom
        if (scrollTop + clientHeight >= scrollHeight - 600) {
            if (nextPageToken && !isFetching) {
                fetchCraftVideos();
            }
        }
    }
});

// Initial Load
fetchCraftVideos();